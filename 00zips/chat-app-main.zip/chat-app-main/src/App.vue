<template>
	<main class="app">
		<router-view></router-view>
	</main>
</template>

<style scoped>
	.app {
		@apply min-h-screen bg-primary p-5 lg:p-5 w-full md:px-28 lg:w-4/12 md:mx-auto xl:w-3/12
	}
</style>
