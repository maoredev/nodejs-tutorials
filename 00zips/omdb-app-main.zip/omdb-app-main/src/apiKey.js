export default {
   omdb: {
      key: '44f01b9e',
      endPoint: 'http://www.omdbapi.com/' 
   }
}