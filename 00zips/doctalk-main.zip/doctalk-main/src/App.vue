<template>

  <Header></Header>
  <Appointment></Appointment>
  <Nearby></Nearby>
  <Navbar></Navbar>
  
</template>

<script setup>

  import Header from './components/Header.vue'
  import Appointment from './components/Appointment.vue'
  import Nearby from './components/Nearby.vue'
  import Navbar from './components/Navbar.vue'

</script>
