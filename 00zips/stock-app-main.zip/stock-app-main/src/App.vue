<template>
	<router-view></router-view>
</template>

<style>
   
   /* Import all style here */
   @import "./style/reset.css";
   @import "./style/var.css";
   @import "./style/animation.css";
   @import "./style/components/container.css";
   @import "./style/components/form.css";
   @import "./style/components/heading.css";
   @import "./style/views/login-view.css";
   
   
</style>