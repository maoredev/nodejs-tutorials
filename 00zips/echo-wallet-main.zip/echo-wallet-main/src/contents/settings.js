export default [
  {
    name: 'Nama pengguna',
    description: 'Atur nama pengguna anda disini',
    to: ''
  },
  {
    name: 'Email',
    description: 'Atur email anda disini',
    to: ''
  },
  {
    name: 'Kata sandi',
    description: 'Atur kata sandi anda disini',
    to: ''
  },
  {
    name: 'Keluar',
    description: 'Keluar dari akun anda',
    to: 'Login'
  }
]
