//Conten for catgory product
//For marketplace

export default [
  {
    name: 'Semua',
    id: 1
  },
  {
    name: 'Aksesoris',
    id: 2
  },
  {
    name: 'Tas',
    id: 3
  },
  {
    name: 'Kerajinan',
    id: 4
  }
]
