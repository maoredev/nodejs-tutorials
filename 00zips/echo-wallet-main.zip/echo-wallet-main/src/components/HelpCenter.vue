<template>
    <section class="mt-10 text-gray-300">
        <div class="flex gap-3">
            <span class="bg-secondary rounded-lg grid place-items-center w-2/12 p-1">
                <i class="fas fa-lightbulb text-sm"></i>
            </span>
            <p class="text-sm w-10/12">
                Silahkan hubungi <a class="text-blue-500">Pusat Bantuan</a> jika mengalami kendala dalam menggunakan layanan
            </p>
        </div>
    </section>
</template>