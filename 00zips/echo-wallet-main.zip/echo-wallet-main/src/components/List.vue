<template>
	<main class="w-full border-t border-gray-600 flex flex-wrap justify-between items-center mb-5 overflow-hidden">
		<slot name="start"></slot>
		<slot name="end"></slot>
		<slot name="bottom"></slot>
	</main>
</template>
