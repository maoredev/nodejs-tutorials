export default (router) => {
    
    setTimeout(() => {
        router.go(-1)
    }, 300);
}