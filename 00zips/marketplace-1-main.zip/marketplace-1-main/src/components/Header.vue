<template>
   <section class="mb-8 w-full flex justify-between">
      <!-- Greetings -->
      <div class="font-medium slide-animation">
         <p class="text-xs">Hi, Windy 👏🏻</p>
         <h3>Good morning</h3>
      </div>
      
      <!-- Profile -->
      <span class="w-2/12 slide-animation">
         <img class="rounded-full" src="/female.jpg" alt="profile" />
      </span>
   </section>
</template>