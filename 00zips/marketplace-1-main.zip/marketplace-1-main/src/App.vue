<template>
	<main class="app">
		<router-view></router-view>
	</main>
</template>

<style scoped>
   
   .app {
      @apply p-5 w-full md:w-6/12 lg:w-5/12 xl:w-3/12 mx-auto h-screen bg-white;
   }
   
</style>
