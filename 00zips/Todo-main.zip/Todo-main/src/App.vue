<template>
  <main class="app">
    <router-view></router-view>
  </main>
</template>

<style scoped>
  
  .app {
    @apply pb-3 h-screen bg-white w-full md:w-6/12 lg:w-4/12 xl:w-3/12 mx-auto
  }
  
</style>