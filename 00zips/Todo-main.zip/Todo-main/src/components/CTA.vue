<template>
  <section class="fixed left-0 right-0 bottom-0">
    <div class="bg-white border-t-2 border-gray-100 w-full mx-auto md:w-6/12 lg:w-4/12 xl:w-3/12 p-5 flex justify-between">
      <button type="button" class="px-6 py-2 rounded-2xl text-gray-600 bg-gray-200 focus:bg-gray-50 focus:ring-1 focu:ring-gray-200 duration-300">
        <i class="fas fa-comments"></i>
        Chat
      </button>
      <button type="button" class="bg-blue-600 focus:bg-blue-400 focus:ring-1 focus:ring-blue-600 duration-300 focus:text-gray-100 text-gray-50 px-6 py-3 rounded-2xl">
        <i class="fa fa-calendar mr-1"></i>
        Schedule meeting
      </button>
    </div>
  </section>
</template>