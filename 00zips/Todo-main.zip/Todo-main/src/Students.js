//Contents for students list

const Students = [
  {
    name: 'William Runnel',
    progress: '75%',
    lastMeet: 'Yesterday',
    img: '/profile.jpg'
  },
  {
    name: 'Johnson',
    progress: '86%',
    lastMeet: 'Sun, 22nd July',
    img: '/profile-2.jpg'
  },
  {
    name: 'Samuel Lingard',
    progress: '97%',
    lastMeet: 'Yesterday',
    img: '/profile-3.jpg'
  },
  {
    name: 'William Runnel',
    progress: '75%',
    lastMeet: 'Yesterday',
    img: '/profile.jpg'
  },
  {
    name: 'Johnson',
    progress: '86%',
    lastMeet: 'Sun, 22nd July',
    img: '/profile-2.jpg'
  },
  {
    name: 'Samuel Lingard',
    progress: '97%',
    lastMeet: 'Yesterday',
    img: '/profile-3.jpg'
  }
];

export default Students;